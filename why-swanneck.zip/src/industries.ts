/* Industries Page Entry */
import './style.css';
import { initPage } from './shared';
initPage('industries');
