/* Products Page Entry */
import './style.css';
import { initPage } from './shared';
initPage('products');
