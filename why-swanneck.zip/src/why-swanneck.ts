/* Why Swanneck Page Entry */
import './style.css';
import { initPage } from './shared';
initPage('why-swanneck');
