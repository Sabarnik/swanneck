/* Sustainability Page Entry */
import './style.css';
import { initPage } from './shared';
initPage('sustainability');
